function logout(){
    delete password;
    delete username;
    location.href="index.html";
}